package Tests;

public class TestRecord {

}
