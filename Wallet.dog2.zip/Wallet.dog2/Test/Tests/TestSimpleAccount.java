package Tests;

import Implements.SimpleAccount;
import org.junit.Before;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestSimpleAccount {

    @Before
    public void setup(){

        SimpleAccount testAccount = new SimpleAccount("testing");
    }

    @Test
    public void testSetLocation(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        testAccount.setLocation(1);
        assertEquals(testAccount.getNumber(),1);
    }

    @Test
    public void testAddMoney(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        testAccount.addMoney(testAccount,1,500.0);
        assertEquals(testAccount.getAmount(),500.0);
    }

    @Test
    public void testWithdrawMoney(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        testAccount.addMoney(testAccount,1,500.0);
        testAccount.withdrawMoney(testAccount,100.0);
        assertEquals(testAccount.getAmount(),400.0);
    }
    @Test
    public void testWithdrawMoneySmall(){
        SimpleAccount testAccount = new SimpleAccount("testing");

        testAccount.withdrawMoney(testAccount,100.0);
        assertEquals(testAccount.getAmount(),-100.0);
    }
}
