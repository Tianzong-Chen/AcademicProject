package Tests;

import Implements.BasicSavingAccount;
import Implements.MyWallet;
import Implements.SimpleAccount;
import model.exception.AccountDoesNotExistException;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;

public class TestMyWallet {

    MyWallet testMyWallet = new MyWallet();

    @Before
    public void setUp(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        SimpleAccount testAccount2 = new SimpleAccount("testing2");
        SimpleAccount testAccount3 = new SimpleAccount("testing3");
//        testMyWallet.setUpAll();
        testMyWallet.makeNewAccount(testAccount,1);
        testMyWallet.makeNewAccount(testAccount2,3);
        testMyWallet.makeNewAccount(testAccount3,6);

    }


    @Test
    public void testGetEAccount(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        SimpleAccount testAccount2 = new SimpleAccount("testing2");
        SimpleAccount testAccount3 = new SimpleAccount("testing3");
//        testMyWallet.setUpAll();
        testMyWallet.makeNewAccount(testAccount,1);
        testMyWallet.makeNewAccount(testAccount2,3);
        testMyWallet.makeNewAccount(testAccount3,6);
        assertEquals(testMyWallet.getExistedAccount("testing"),1);
        assertEquals(testMyWallet.getExistedAccount("testing2"),3);
        assertEquals(testMyWallet.getExistedAccount("testing3"),6);

    }

    @Test
    public void testFindingEAccount() throws AccountDoesNotExistException {
        testMyWallet.findingExistedAccount("testing");
        assertEquals(testMyWallet.findingExistedAccount("testing").getName(),"testing");

    }

    // Tests we can only add money to the existed account
    @Test
    public void testAddMoney(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        SimpleAccount testAccount2 = new SimpleAccount("testing2");
        SimpleAccount testAccount3 = new SimpleAccount("testing3");
        BasicSavingAccount BSA = new BasicSavingAccount("testing4");

//        testMyWallet.setUpAll();
        testMyWallet.makeNewAccount(testAccount,1);
        testMyWallet.makeNewAccount(testAccount2,3);
        testMyWallet.makeNewAccount(testAccount3,6);
        testMyWallet.makeNewAccount(BSA,2);

        assertTrue(testMyWallet.addMoneyToSpecificAccount(testAccount,1,500.0));
        assertFalse(testMyWallet.addMoneyToSpecificAccount(testAccount,2,500.0));
        assertTrue(testMyWallet.addMoneyToSpecificAccount(testAccount2,3,400.0));
        assertTrue(testMyWallet.addMoneyToSpecificAccount(testAccount3,6,300.0));
        assertTrue(testMyWallet.addMoneyToSpecificAccount(BSA,2,100.0));
        assertFalse(BSA.getAmount() == 100.0);

        assertEquals(testAccount.getAmount(),500.0);
        assertEquals(testAccount2.getAmount(),400.0);
        assertEquals(testAccount3.getAmount(),300.0);
        assertEquals(BSA.getAmount(),100.0*0.5);


    }

    // Tests we can only withdraw the money from a existed account which has enough amount.
    @Test
    public void testWithdrawMoney(){
        SimpleAccount testAccount = new SimpleAccount("testing");
        SimpleAccount testAccount2 = new SimpleAccount("testing2");
        SimpleAccount testAccount3 = new SimpleAccount("testing3");
//        testMyWallet.setUpAll();
        testMyWallet.makeNewAccount(testAccount,1);
        testMyWallet.makeNewAccount(testAccount2,3);
        testMyWallet.makeNewAccount(testAccount3,6);
        testAccount.addMoney(testAccount,1,500.0);
        testAccount2.addMoney(testAccount2,3,400.0);
        testAccount3.addMoney(testAccount3,6,300.0);
        assertFalse(testMyWallet.withdrawMoneyFromSpecificAccount(testAccount,1,600.0));
        assertTrue(testMyWallet.withdrawMoneyFromSpecificAccount(testAccount,1,100.0));
        assertEquals(testAccount.getAmount(),400.0);
        assertFalse(testMyWallet.withdrawMoneyFromSpecificAccount(testAccount,2,100.0));
        assertTrue(testMyWallet.withdrawMoneyFromSpecificAccount(testAccount2,3,100.0));
        assertEquals(testAccount.getAmount(),400.0);
        assertEquals(testAccount2.getAmount(),300.0);

    }


}
