package Tests;

import Implements.MyWallet;
import Implements.SimpleAccount;
import model.Account;
import model.exception.AccountDoesNotExistException;
import org.junit.Test;

import static junit.framework.TestCase.fail;

public class TestAccountDoesNotExistException {
    MyWallet testWallet = new MyWallet();

    @Test
    public void TestAccountDoesNotExistException (){
//        testWallet.setUpAll();
        Account testAccount = new SimpleAccount("test1");
        Account testAccount2 = new SimpleAccount("test2");

        testWallet.makeNewAccount(testAccount,1);

        try {
            testWallet.confirmCreatedAccount("test1",1);
        } catch (AccountDoesNotExistException e) {
            fail("ADNEException should not have been thrown");
            e.printStackTrace();
        }


        try {
            testWallet.confirmCreatedAccount("test2",1);
        } catch (AccountDoesNotExistException e) {
            e.printStackTrace();
        }


    }

    @Test
    public void TestAccountDoesNotExistException2 (){
//        testWallet.setUpAll();
        Account testAccount = new SimpleAccount("test1");
        Account testAccount2 = new SimpleAccount("test2");

        testWallet.makeNewAccount(testAccount,1);

        try {
            testWallet.confirmCreatedAccount("test1",2);
        } catch (AccountDoesNotExistException e) {

            e.printStackTrace();
        }


        try {
            testWallet.confirmCreatedAccount("test2",2);
        } catch (AccountDoesNotExistException e) {
            e.printStackTrace();
        }


    }



}
