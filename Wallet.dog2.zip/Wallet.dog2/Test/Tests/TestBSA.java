package Tests;

import Implements.BasicSavingAccount;
import model.Account;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestBSA {

    @Test
    public void TestAddMoneyPisAccount(){
        Account testAccount = new BasicSavingAccount("testing");
        testAccount.addMoney(testAccount,1,100.0);
        assertEquals(testAccount.getAmount(),100.0*0.5);
    }

    @Test
    public void TestAddMoneyPisBSA(){
        BasicSavingAccount testAccount = new BasicSavingAccount("testing");
        testAccount.addMoney(testAccount,1,100.0);
        assertEquals(testAccount.getAmount(),100.0*0.5);
    }



}
