package model.exception;

public class NegativeAmountException extends Exception{

}
