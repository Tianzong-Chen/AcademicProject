package model.exception;

public class AccountDoesNotExistException extends Exception {
}
