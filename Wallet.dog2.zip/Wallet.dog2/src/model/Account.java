package model;

import Implements.Manager;
import Implements.Record;

import java.util.ArrayList;
import java.util.Objects;

public abstract class Account {

    protected ArrayList<Record> Records;
//    Wallet aWallet;
    protected String name;
    protected double amount;
    protected int number;


    public void addRecord(Record r){
        if(!Records.contains(r)){
            Records.add(r);
            r.addAccount(this);
        }
    }

    public void removeRecord(Record r){

        if(Records.contains(r)){
            Records.remove(r);
            r.removeAccount(this);
        }
    }

    public void printRecord(){
        for (Record r: Records) {
            System.out.println(r.getThisRecord());
        }
    }

    //getter
    //EFFECTS: Returns the name of the SimpleAccount.
    public String getName(){
        return name;
    };

    //EFFECTS: Returns the amount within the SimpleAccount.
    public double getAmount(){
        return amount;
    };

    //EFFECTS: Returns the location of the SimpleAccount.
    public int getNumber(){
        return number;
    }

    //EFFECTS: Set the Account's location.
    public void setLocation(int loc) {
        number = loc; }

    //EFFECTS: Add the given amount of money into the given SimpleAccount.
    public abstract boolean addMoney(Account a, int location, double newAmount);

    //EFFECTS: Withdraw the given amount of money from the given SimpleAccount.
    public  boolean withdrawMoney(Account a, double fees){

        amount = a.getAmount()- fees;
        Record r = new Record(-fees);
        Manager m = new Manager();
        r.addObserver(m);
        a.addRecord(r);
        return true;
    };

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return Objects.equals(name, account.name);
    }

    @Override
    public int hashCode() {

        return Objects.hash(name);
    }

}


