package model;

import model.exception.AccountDoesNotExistException;

public interface Wallet {

//    List<Account> accounts = new ArrayList<>();
//
//    void addAccount(Account a);
//
//    void removeAccount(Account a);


    //EFFECTS: Setup all singleAccounts within the new MyWallet
//    void setUpAll();

    // EFFECTS: Returns the location of an existed account with given name.
    int getExistedAccount(String name);

    // EFFECTS: Returns the SimpleAccount with the given name.
    Account findingExistedAccount(String name) throws AccountDoesNotExistException;

    // MODIFIES: this and SimpleAccount
    // EFFECTS: creates the account at the requested location if it is a valid location,
    //          and lets me know the location.
    boolean makeNewAccount(Account a, int location);

    // MODIFIES: this and SimpleAccount
    // EFFECTS: Adds money into the requested  account if it is existed,
    //
    boolean addMoneyToSpecificAccount(Account a, int location, double newAmount);

    // MODIFIES: this and SimpleAccount
    // EFFECTS: Withdraw money from the requested account
    //
    boolean withdrawMoneyFromSpecificAccount(Account a, int location, double fees);
}
