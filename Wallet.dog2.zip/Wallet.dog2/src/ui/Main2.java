package ui;

import Implements.BasicSavingAccount;
import Implements.MyWallet;
import Implements.Record;
import Implements.SimpleAccount;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.Account;
import model.exception.AccountDoesNotExistException;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

public class Main2 extends Application {

    Stage window;
    Scene scene1, scene2;

    Button button;

    private Map<String, ArrayList<Account>> accountMap = new HashMap<>();
    private Record r = new Record(0.0);
    MyWallet myWallet = new MyWallet();
    ArrayList<Account> as = new ArrayList<>();
    ArrayList<Account> bs = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    String operation = "";

    BufferedReader br = null;



    public static void main(String[] args) throws IOException, AccountDoesNotExistException, URISyntaxException {
        launch(args);

    }


    public static ArrayList<String> splitOnSpace(String line) {
        String[] splits = line.split(" ");
        return new ArrayList<>(Arrays.asList(splits));


    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        accountMap.put("BSA",as);
        accountMap.put("Simple",bs);
        myWallet.load("inputfile.txt");

        window = primaryStage;
        window.setTitle("Wallet Dog");

        window.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                event.consume();
                closeProgram();
            }
        });



        // The Pane for the Deposit Scene
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10,10,10,10));
        grid.setVgap(8);
        grid.setHgap(10);

        //Deposit Amount Label
        javafx.scene.control.Label depositLabel = new javafx.scene.control.Label("Deposit Amount");
        GridPane.setConstraints(depositLabel,0,0);

        // Deposit amount input
        final javafx.scene.control.TextField depositInput = new javafx.scene.control.TextField();
        depositInput.setPromptText(" Dollars ");
        GridPane.setConstraints(depositInput,1,0);

        //Name Label
        javafx.scene.control.Label nameLabel = new javafx.scene.control.Label("Account's Name");
        GridPane.setConstraints(nameLabel,0,1);

        //Name input
        final javafx.scene.control.TextField nameInput = new javafx.scene.control.TextField();
        nameInput.setPromptText("Please enter the account's Name");
        GridPane.setConstraints(nameInput,1,1);

        //Number Label
        javafx.scene.control.Label numberLabel = new javafx.scene.control.Label("Account's Number");
        GridPane.setConstraints(numberLabel,0,2);

        //Number input
        final javafx.scene.control.TextField numberInput = new TextField();
        numberInput.setPromptText("Please enter the account's Number");
        GridPane.setConstraints(numberInput,1,2);

        //Button Deposit
        Button depositButton = new Button("Deposit");
        GridPane.setConstraints(depositButton, 1 ,3);
        depositButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                isInt(depositInput,depositInput.getText());
                isInt(numberInput,numberInput.getText());

                int income = Integer.parseInt(depositInput.getText());
                String name = nameInput.getText();
                int number = Integer.parseInt(numberInput.getText());

                Account a0 = null;
                try {
                    a0 = myWallet.findingExistedAccount(name);
                } catch (AccountDoesNotExistException e) {
                    System.out.println("Sorry Account's not Existed");
                }

                myWallet.addMoneyToSpecificAccount(a0,number,income);
                try {
                    myWallet.save();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                myWallet.printAccountsList();
            }
        });

        // Button from Deposit back to Scene1
        Button fromDepositBackButton = new Button("Go Back");
        GridPane.setConstraints(fromDepositBackButton,1,4);
        fromDepositBackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene1);
            }
        });

        grid.getChildren().addAll(depositLabel,depositInput,nameLabel,nameInput,numberLabel,
                numberInput,depositButton,fromDepositBackButton);
        final Scene depositScene = new Scene(grid, 500,200);

        //-----------------------------------------------------------------------------------------------------


        // The Pane for the Withdraw Scene
        GridPane grid3 = new GridPane();
        grid3.setPadding(new Insets(10,10,10,10));
        grid3.setVgap(8);
        grid3.setHgap(10);

        //Withdraw Amount Label
        javafx.scene.control.Label withdrawLabel = new javafx.scene.control.Label("Withdraw Amount");
        GridPane.setConstraints(withdrawLabel,0,0);

        // Withdraw amount input
        final javafx.scene.control.TextField withdrawInput = new javafx.scene.control.TextField();
        withdrawInput.setPromptText(" Dollars ");
        GridPane.setConstraints(withdrawInput,1,0);

        //Withdraw Name Label
        javafx.scene.control.Label withdrawNameLabel = new javafx.scene.control.Label("Account's Name");
        GridPane.setConstraints(withdrawNameLabel,0,1);

        //Withdraw Name input
        final javafx.scene.control.TextField withdrawNameInput = new javafx.scene.control.TextField();
        withdrawNameInput.setPromptText("Please enter the account's Name");
        GridPane.setConstraints(withdrawNameInput,1,1);

        //Withdraw  Number Label
        javafx.scene.control.Label withdrawNumberLabel = new javafx.scene.control.Label("Account's Number");
        GridPane.setConstraints(withdrawNumberLabel,0,2);

        //Withdraw Number input
        final javafx.scene.control.TextField withdrawNumberInput = new TextField();
        withdrawNumberInput.setPromptText("Please enter the account's Number");
        GridPane.setConstraints(withdrawNumberInput,1,2);

        //Button withdraw
        Button withdrawButton = new Button("Withdraw");
        GridPane.setConstraints(withdrawButton, 1 ,3);
        withdrawButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                isInt(withdrawInput,withdrawInput.getText());
                isInt(withdrawNumberInput,withdrawNumberInput.getText());

                int fees = Integer.parseInt(withdrawInput.getText());
                String withdrawName = withdrawNameInput.getText();
                int withdrawNumber = Integer.parseInt(withdrawNumberInput.getText());

                Account a0 = null;
                try {
                    a0 = myWallet.findingExistedAccount(withdrawName);
                } catch (AccountDoesNotExistException e) {
                    e.printStackTrace();
                    System.out.println("Sorry, account does not exists.");
                    // Make a new Scene for Warning!!!
                }

                myWallet.withdrawMoneyFromSpecificAccount(a0,withdrawNumber,fees);
                try {
                    myWallet.save();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                myWallet.printAccountsList();
            }
        });

        // Button from Deposit back to Scene1
        Button fromWithdrawBackButton = new Button("Go Back");
        GridPane.setConstraints(fromWithdrawBackButton,1,4);
        fromWithdrawBackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene1);
            }
        });

        grid3.getChildren().addAll(withdrawLabel,withdrawInput,withdrawNameLabel,withdrawNameInput,withdrawNumberLabel,
                withdrawNumberInput,withdrawButton,fromWithdrawBackButton);
        final Scene withdrawScene = new Scene(grid3, 500,200);

//-----------------------------------------------------------------------------------------------------

        // The Pane for BSA Creating
        GridPane grid2 = new GridPane();
        grid2.setPadding(new Insets(10,10,10,10));
        grid2.setVgap(8);
        grid2.setHgap(10);

        //BSA Name Label
        javafx.scene.control.Label bsaAccountNameLabel = new javafx.scene.control.Label("Create A Name");
        GridPane.setConstraints(bsaAccountNameLabel,0,0);

        //BSA Name input
        final TextField bsaAccountNameInput = new TextField();
        numberInput.setPromptText("Enter your preferred name");
        GridPane.setConstraints(bsaAccountNameInput,1,0);

        //Number Label
        javafx.scene.control.Label bsaNumberLabel = new Label("Account's Number");
        GridPane.setConstraints(bsaNumberLabel,0,2);

        //Number input
        final TextField bsaNumberInput = new TextField();
        numberInput.setPromptText("Please enter the account's Number");
        GridPane.setConstraints(bsaNumberInput,1,2);

        //Button Create BSA
        Button createBSAButton = new Button("Create Now!");
        GridPane.setConstraints(createBSAButton, 1 ,3);
        createBSAButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                isInt(bsaNumberInput,bsaNumberInput.getText());

                String name = bsaAccountNameInput.getText();
                int number = Integer.parseInt(bsaNumberInput.getText());
                BasicSavingAccount newBSA = new BasicSavingAccount(name);
                if(!accountMap.get("BSA").contains(newBSA)){
                    accountMap.get("BSA").add(newBSA);
                }

                System.out.println("You have created an BSA");
                myWallet.makeNewAccount(newBSA, number);
                try {
                    myWallet.save();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                myWallet.printAccountsList();

            }
        });

        //Button Going Back
        Button fromBsaBackButton = new Button("Go Back ");
        GridPane.setConstraints(fromBsaBackButton,1,4);
        fromBsaBackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene1);
            }
        });

        grid2.getChildren().addAll(bsaAccountNameLabel,bsaAccountNameInput,bsaNumberLabel,bsaNumberInput,
                createBSAButton,fromBsaBackButton);
        final Scene creatingBsa = new Scene(grid2, 500,200);

//-----------------------------------------------------------------------------------------------------

        // The Pane for Simple Creating
        GridPane grid4 = new GridPane();
        grid4.setPadding(new Insets(10,10,10,10));
        grid4.setVgap(8);
        grid4.setHgap(10);

        //Simple Name Label
        javafx.scene.control.Label simpleAccountLabel = new javafx.scene.control.Label("Create A Name");
        GridPane.setConstraints(simpleAccountLabel,0,0);

        //Simple Name input
        final TextField simpleAccountInput = new TextField();
        simpleAccountInput.setPromptText("Enter your preferred name");
        GridPane.setConstraints(simpleAccountInput,1,0);

        //Number Label
        javafx.scene.control.Label simpleNumberLabel = new Label("Account's Number");
        GridPane.setConstraints(simpleNumberLabel,0,2);

        //Number input
        final TextField simpleNumberInput = new TextField();
        simpleNumberInput.setPromptText("Please enter the account's Number");
        GridPane.setConstraints(simpleNumberInput,1,2);

        //Button Create SImple
        Button createSimpleButton = new Button("Create Now!");
        GridPane.setConstraints(createSimpleButton, 1 ,3);
        createSimpleButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                isInt(simpleNumberInput,simpleNumberInput.getText());

                String simpleName = simpleAccountInput.getText();
                int number = Integer.parseInt(simpleNumberInput.getText());
                SimpleAccount newSimpleAccount = new SimpleAccount(simpleName);
                if(!accountMap.get("Simple").contains(newSimpleAccount)){
                    accountMap.get("Simple").add(newSimpleAccount);
                }
                System.out.println("You have created an account");
                myWallet.makeNewAccount(newSimpleAccount, number);
                try {
                    myWallet.save();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                myWallet.printAccountsList();
            }

        });

        //Button Going Back
        Button fromSimpleBackButton = new Button("Go Back ");
        GridPane.setConstraints(fromSimpleBackButton,1,4);
        fromSimpleBackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene1);
            }
        });

        grid4.getChildren().addAll(simpleAccountLabel,simpleAccountInput,simpleNumberLabel,simpleNumberInput,
                createSimpleButton,fromSimpleBackButton);
        final Scene creatingSimple = new Scene(grid4, 500,200);

//----------------------------------------------------------------------------------------------------

        // ChoiceBox for the NewAccount Scene
        final ChoiceBox<String> choiceBox = new ChoiceBox<>();

        choiceBox.getItems().add("Basic Saving Account");
        choiceBox.getItems().add("Simple Account");

        // Set the default value
        choiceBox.setValue("Simple Account");

        //Button Deposit
        Button nextButton = new Button("Next ");
        nextButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(getChoice(choiceBox)== true)
                    window.setScene(creatingBsa);
                else if (getChoice(choiceBox)==false)
                    window.setScene(creatingSimple);


            }
        });

        // The Pane for the NewAccount Scene
        VBox newAccount = new VBox(10);
        newAccount.setPadding(new Insets(20,20,20,20));
        newAccount.getChildren().addAll(choiceBox, nextButton);

        final Scene newAccountScene = new Scene(newAccount, 500, 200);



        //TopMenu for Scene1
        Insets insets = new Insets(10);
        HBox topMenu = new HBox();
        Button buttonA = new Button("DepositMoney");
        buttonA.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(depositScene);
            }
        });
        Button buttonB = new Button("Withdraw");
        buttonB.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(withdrawScene);
            }
        });
        Button buttonC = new Button("Create A New Account");
        buttonC.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(newAccountScene);
            }
        });
        Button buttonD = new Button("Print Accounts List");
        buttonD.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                myWallet.printAccountsList();
            }
        });
        topMenu.getChildren().addAll(buttonA,buttonB,buttonC,buttonD);
        HBox.setMargin(buttonA,insets);
        HBox.setMargin(buttonB,insets);
        HBox.setMargin(buttonC,insets);
        HBox.setMargin(buttonD,insets);



        // Button 1
        Button button1 = new Button("Learn more about Exchange Rate");
//        button1.setOnAction( e -> window.setScene(scene2));
        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene2);
            }
        });

        // Button 3
        Button button3 = new Button("Quit");
        button3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                boolean answer = ConfirmBox.display("Sure you want to quit","Sure you want to exit?");
                if(answer)
                    window.close();
            }
        });

        //leftMenu for Scene1
        VBox leftMenu = new VBox(20);
        leftMenu.getChildren().add(button1);
        leftMenu.getChildren().add(button3);


        // The pane for the Main Scene : Scene1
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(topMenu);
        BorderPane.setMargin(topMenu, insets);
        borderPane.setLeft(leftMenu);
        BorderPane.setMargin(leftMenu, insets);
        ImageView imageView = new ImageView();
        imageView.setImage(new Image("file:///Users/wolf/Desktop/文艺复星球第4期基础班/O.png"));
        borderPane.setCenter(imageView);
        scene1 = new Scene(borderPane, 1000,500);



        //Button 2
        Button button2 = new Button("Back to the Main Menu");
        button2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene1);
            }
        });
        //Button 4
        Button button4 = new Button("View Current Exchange Rate");
        button4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    viewExchangeRate();
                } catch (IOException e) {
                    System.out.println("IOException!!");
                } catch (URISyntaxException e) {
                    System.out.println("Invalid URI");

                }
            }
        });


        //layout 2
        VBox leftMenu2 = new VBox(20);
        leftMenu2.getChildren().add(button4);
        leftMenu2.getChildren().add(button2);

        BorderPane layout2 = new BorderPane();
        layout2.setLeft(leftMenu2);
        BorderPane.setMargin(leftMenu2, insets);
        scene2 = new Scene(layout2, 600, 300);

        //Default
        window.setScene(scene1);
        window.setTitle(" Wallet Dog ");
        window.show();

    }

    private void closeProgram(){
        boolean answer = ConfirmBox.display("Sure you want to exit?","");
        if(answer)
            window.close();
    }

    private boolean isInt(TextField input, String message){
        try{
            int amount = Integer.parseInt(input.getText());
            return true;
        }catch (NumberFormatException e){
            System.out.println("Error: " + message+ " is not a number!");
            return false;
        }
    }

    private boolean getChoice (ChoiceBox<String> choiceBox){
        String choice = choiceBox.getValue();
        if(choice == "Basic Saving Account")
            return true;
        return false;
    }

    private  void viewExchangeRate() throws IOException, URISyntaxException {

        Desktop d = Desktop.getDesktop();
        d.browse(new URI("https://www.xe.com/currencyconverter/convert/?Amount=1&From=CAD&To=CNY"));

    }
}