package ui;

import Implements.*;
import model.Account;
import model.exception.AccountDoesNotExistException;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

public class Main {

    private Map<String, ArrayList<Account>> accountMap = new HashMap<>();
    private Record r = new Record(0.0);
    MyWallet myWallet = new MyWallet();
    ArrayList<Account> as = new ArrayList<>();
    ArrayList<Account> bs = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    String operation = "";

    BufferedReader br = null;



    public static void main(String[] args) throws IOException, AccountDoesNotExistException, URISyntaxException {
        Main m = new Main();
        m.start();

    }

    public void start() throws IOException, AccountDoesNotExistException, URISyntaxException {
        accountMap.put("BSA",as);
        accountMap.put("Simple",bs);
        myWallet.load("inputfile.txt");

        while (true){
            displayMenu();
            System.out.println("Please select an option");
            operation = scanner.nextLine();
            if(operation.equals("n"))
                createNewAccount();
            else if(operation.equals("d"))
                doDeposit();
            else if(operation.equals("w"))
                doWithdraw();
            else if(operation.equals("p"))
                myWallet.printAccountsList();
            else if(operation.equals("s"))
                myWallet.printRecord();
            else if(operation.equals("c1"))
                doClean();
            else if(operation.equals("c2"))
                doCheck();
            else if(operation.equals("v"))
                viewExchangeRate();
            else if(operation.equals("q"))
                break;

        }
    }

    private void displayMenu() {
        System.out.println("Please select from: ");
        System.out.println("d -> deposit");
        System.out.println("w -> withdraw");
        System.out.println("p -> print all accounts");
        System.out.println("s -> show records");
        System.out.println("c1 -> Clean some records");
        System.out.println("c2 -> Check the amount of an Account");
        System.out.println("v -> View the exchange rate");
        System.out.println("q -> quit");
    }

    private  void viewExchangeRate() throws IOException, URISyntaxException {

        Desktop d = Desktop.getDesktop();
        d.browse(new URI("https://www.xe.com/currencyconverter/convert/?Amount=1&From=CAD&To=CNY"));

    }


    private  void displayMenuForAccount(){
        System.out.println("Please Select the type of the Account");
        System.out.println("BSA -> Basic Saving Account");
        System.out.println("S -> Simple Account");
    }

    private void doDeposit() throws AccountDoesNotExistException, IOException {
        System.out.println("Please entry the amount you want to deposit");
        int income = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Please choose the account you want deposit to");
        operation = scanner.nextLine();
        Account a0 = myWallet.findingExistedAccount(operation);
        int number = myWallet.getExistedAccount(operation);
        myWallet.addMoneyToSpecificAccount(a0,number,income);
        myWallet.save();

    }

    private  void createNewAccount() throws IOException {
        System.out.println("Please select a type");
        displayMenuForAccount();
        operation = scanner.nextLine();
        if(operation.equals("BSA")){
            System.out.println("Please select a name ");
            operation = scanner.nextLine();
            System.out.println("Please se;ect a location");
            int loc = scanner.nextInt();
            scanner.nextLine();
            System.out.println("you selected: " + loc);
            BasicSavingAccount newBSA = new BasicSavingAccount(operation);
            if(!accountMap.get("BSA").contains(newBSA)){
                accountMap.get("BSA").add(newBSA);
            }

            System.out.println("You have created an BSA");
            myWallet.makeNewAccount(newBSA, loc);
            myWallet.save();
        }
        else if (operation.equals("S")){
            System.out.println("Please select a name ");
            operation = scanner.nextLine();
            System.out.println("Please se;ect a location");
            int loc = scanner.nextInt();
            scanner.nextLine();
            System.out.println("you selected: " + loc);
            SimpleAccount newSimpleAccount = new SimpleAccount(operation);
            if(!accountMap.get("Simple").contains(newSimpleAccount)){
                accountMap.get("Simple").add(newSimpleAccount);
            }
            System.out.println("You have created an account");
            myWallet.makeNewAccount(newSimpleAccount, loc);
            myWallet.save();}

        for (Account a: accountMap.get("BSA")) {
            System.out.println("BSA :" + a.getName());
        }
        for (Account b: accountMap.get("Simple")) {
            System.out.println("Simple :"+ b.getName());

        }

    }

    private void doWithdraw() throws IOException, AccountDoesNotExistException {
        System.out.println("Please entry the amount you want to withdraw");
        int fees = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Please choose the account you want to withdraw");
        operation = scanner.nextLine();
        Account a0 = myWallet.findingExistedAccount(operation);
        int number = myWallet.getExistedAccount(operation);
        myWallet.withdrawMoneyFromSpecificAccount(a0,number,fees);
        myWallet.save();

    }

    public void doClean() throws AccountDoesNotExistException {
        System.out.println("Which Account's records ?");
        operation = scanner.nextLine();
        System.out.println("Number you want to clean up");
        int d0 = scanner.nextInt();
        Record r0 = new Record(d0);
//        Manager m = new Manager();
//        r0.addObserver(m);
        r = r0;
        myWallet.findingExistedAccount(operation).removeRecord(r);
    }

    private  void doCheck() throws IOException {
        System.out.println("Please entry the account's name that you want to check");
        operation = scanner.nextLine();

        double Amount = 0;
        try {
            Amount = myWallet.findingExistedAccount(operation).getAmount();
        } catch (AccountDoesNotExistException e) {
            System.out.println("Sorry, Account dose not exists");
            e.printStackTrace();
        }
        System.out.println(Amount);
        myWallet.save();

    }


    public static ArrayList<String> splitOnSpace(String line) {
        String[] splits = line.split(" ");
        return new ArrayList<>(Arrays.asList(splits));


    }
}
