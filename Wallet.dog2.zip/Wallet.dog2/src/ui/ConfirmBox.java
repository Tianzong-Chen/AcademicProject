package ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.awt.*;

public class ConfirmBox {

    static boolean answer;


    public static boolean display(String title, String message){
        final Stage window = new Stage();
        javafx.scene.control.Button button;
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(250.0);
        Label label = new Label();
        label.setText(message);

        // Create two buttons.
        javafx.scene.control.Button yesButton = new javafx.scene.control.Button("Yes");
        javafx.scene.control.Button noButton = new javafx.scene.control.Button("No");

        yesButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                answer = true;
                System.out.println("true");
                window.close();

            }
        });

        noButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                answer = false;
                System.out.println("false");
                window.close();
            }
        });


        VBox layout = new VBox(10);
        layout.getChildren().addAll(yesButton,noButton);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();


        return answer;



    }
}
