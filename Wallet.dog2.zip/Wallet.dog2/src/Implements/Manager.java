package Implements;

import java.util.Observable;
import java.util.Observer;

public class Manager implements Observer {


    @Override
    public void update(Observable o, Object arg) {
        Record record = (Record) o;
        if(record.getThisRecord() > 0)
            System.out.println("We recorded that you have deposited  : " + record.getThisRecord() + " dollars.");
        if(record.getThisRecord() < 0)
            System.out.println("We recorded that you have withdraw  : " + record.getThisRecord() + " dollars.");
    }

}
