package Implements;

import model.Account;
import model.exception.AccountDoesNotExistException;
import model.Loadable;
import model.Savable;
import model.Wallet;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static ui.Main.splitOnSpace;

public class MyWallet implements Wallet, Savable, Loadable{

    private ArrayList<Account> Accounts;



    // EFFECTS: Create a new MyWallet with 6 simpleAccounts.
    public MyWallet() {
        Accounts = new ArrayList<>();
        for (int i = 0; i <= 6; i++) {

            Accounts.add(i, null);
            SimpleAccount a = new SimpleAccount("Active");
            Accounts.set(i,a);
        }
    }

    public void printRecord(){
        for (Account a: Accounts) {
            a.printRecord();
            }
    }

    public void cleanAllRecord(double d0){
        for (Account a: Accounts) {
            Record r = new Record(d0);
            a.removeRecord(r);
        }

    }

    @Override
    // EFFECTS: Returns the location of an existed account with given name.
    public int getExistedAccount(String name){
        for (Account a: Accounts) {
            if(a.getName().equals(name)){
                return a.getNumber(); }
        }
        return 1000;

    };

    @Override
    // EFFECTS: Returns the SimpleAccount with the given name.
    public Account findingExistedAccount(String name) throws AccountDoesNotExistException {
        for ( Account a: Accounts) {
            if(a.getName().equals(name)){
                Account a0 = Accounts.get(getExistedAccount(name));
                return a0;
            }
            
        } throw new AccountDoesNotExistException();
    }


    @Override
    // MODIFIES: this and SimpleAccount
    // EFFECTS: creates the account at the requested location if it is a valid location,
    //          and lets me know the location.
    public boolean makeNewAccount(Account a, int location) {
        if (location > Accounts.size()) {
            System.out.println("We can't create that account");
            return false;
        }
        System.out.println("SimpleAccount  :" + a.getName() + " has been created at  " + "location " +location);
        Accounts.set(location, a);
        a.setLocation(location);
        return true;
    }



    // MODIFIES: this and SimpleAccount
    // EFFECTS: Adds money into the requested  account if it is existed,
    //
    @Override
    public boolean addMoneyToSpecificAccount(Account a, int number, double newAccount){
        if (CheckingAccount(a, number, "Sorry, we can't find the account.")) return false;
        a.addMoney(a,number, newAccount);
        System.out.println("Your money has been added into account "+ a.getName());
        return true;

    }


    // EFFECTS: Checking does an account exists.
    protected boolean CheckingAccount(Account a, int number, String s) {
        try {
            if (!confirmCreatedAccount(a.getName(), number)) ;

        } catch (AccountDoesNotExistException e) {
            System.out.println(s);
            return true;
        }
        return false;
    }

    // REQUIRES: The account has enough money
    // MODIFIES: this and SimpleAccount
    // EFFECTS: Withdraw money from the requested account
    //
    @Override
    public boolean withdrawMoneyFromSpecificAccount(Account a, int number, double fees) {
        if (CheckingAccount(a, number, "Sorry, we can't find this account.")) return false;
        if(a.getAmount() < fees){
                System.out.println("Sorry, this account does not have enough money!");
                return false;
            }
            a.withdrawMoney(a, fees);
            System.out.println("You have withdraw "+ fees+"  from your account "+a.getName());
            return true;
    }


    // MODIFIES: this and SimpleAccount
    // EFFECTS: Confirm the amount of the requested account if it is existed,
    //          and lets me know the total amount within this account.

    public double confirmAmount(SimpleAccount a, int number){
        if (CheckingAccount(a, number, "Sorry, we can't find this account.")) return 0;
        System.out.println("The total amount within SimpleAccount " + a.getName() + "is: "+ a.getAmount());
        return a.getAmount();
    }



    // EFFECTS: prints out all the simpleAccounts. If the account has not been created, print"available"
    public void printAccountsList() {
        for (int i = 0; i < Accounts.size(); i++) {
            Account a = Accounts.get(i);
            if (a != null) {
                System.out.println(i + ":"+" "+ a.getName() + ":  " + a.getAmount());
            }
        }
    }

//    //EFFECTS: returns true if the account is found at that location.
//    public boolean verifyAccount(SimpleAccount a, int location){
//        Account createdAccount = Accounts.get(location);
//        if (createdAccount == null){
//            System.out.println("There is no account at this location");
//            return false;
//        }
//        else if (createdAccount.getName().equals(a.getName())){
//            System.out.println("Yes, the account is created at that location");
//            return true;
//        }
//        return false;
//    }


    //EFFECTS: returns true if the account is crested at that location
    public boolean confirmCreatedAccount(String aName, int location) throws AccountDoesNotExistException {
        if(Accounts.get(location) != null){
            Account createdAccount = Accounts.get(location);
            String createdAccountName = createdAccount.getName();
            boolean isPersonalAccount = createdAccountName.equals(aName);
            if (!isPersonalAccount){
                throw new AccountDoesNotExistException();
            }
            return isPersonalAccount;
        }
        return false;
    }

    @Override
    public void save() throws IOException {

        PrintWriter writer = new PrintWriter("outputfile.txt","UTF-8");

        loadingAccountInformation(writer);
        writer.close();

    }

    private void loadingAccountInformation(PrintWriter writer) {
        for (Account sa : Accounts){

            String str = sa.getName() + " " + Integer.toString(sa.getNumber());
            String str1 = " "+  Double.toString(sa.getAmount());

            writer.println(str + str1);
        }
    }

    @Override
    public void load(String s) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(s));

        for (String line: lines) {
            ArrayList<String> partsOfLine = splitOnSpace(line);
            SimpleAccount newSimpleAccount = new SimpleAccount(partsOfLine.get(0));

            int i = Integer.parseInt(partsOfLine.get(1));
            double i1 = Double.parseDouble(partsOfLine.get(2));

            Accounts.set(i, newSimpleAccount);
            newSimpleAccount.setLocation(i);
            newSimpleAccount.addMoney(newSimpleAccount,i,i1);


        }

    }

}









