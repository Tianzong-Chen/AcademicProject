package Implements;

import model.Account;

import java.util.Objects;
import java.util.Observable;

public class Record extends Observable{

    private Account a0;
    private double r0;

    public Record(double r){
        this.r0 = r;
    }

    public double getThisRecord(){
        return r0;
    }

    public void addAccount(Account a){
        if(!(a0 == a)){
            a0 = a;
            a.addRecord(this);

        }
        this.setChanged();
        this.notifyObservers();
    }

    public void removeAccount(Account a){
        if(a0 == a){
            a0 = null;
            a.removeRecord(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Record record = (Record) o;
        return Double.compare(record.r0, r0) == 0;
    }

    @Override
    public int hashCode() {

        return Objects.hash(r0);
    }
}
