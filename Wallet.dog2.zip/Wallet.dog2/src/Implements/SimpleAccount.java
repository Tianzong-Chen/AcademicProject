package Implements;

import model.Account;

import java.util.ArrayList;

public class SimpleAccount extends Account{


    public SimpleAccount(String name){
       // System.out.println("Making a new account called"+ name);
        this.name = name;
        this.amount = 0;
        this.number = 0;
        this.Records = new ArrayList<Record>();
        Record r0 = new Record(0.0);
        Records.add(r0);
    }

    @Override
    //EFFECTS: Add the given amount of money into the given SimpleAccount.
    public boolean addMoney(Account a, int number, double newAmount) {
        amount =  a.getAmount()+newAmount;
        Record r = new Record(newAmount);
        Manager m = new Manager();
        r.addObserver(m);
        a.addRecord(r);
        return true;
    }

    //EFFECTS: print out the name of this account
    public void printName() { System.out.println(" " + name + " "); }

    //EFFECTS: returns the location of this account's deposit point
    public void confirmLocation() {
        System.out.println( name + "  is created and it is at location " + number);
    }



}
