package Implements;

import model.Account;

import java.util.ArrayList;

public class BasicSavingAccount extends Account {

    public BasicSavingAccount(String name){
        //System.out.println("Making a new account called"+ name);
        this.name = name;
        this.amount = 0;
        this.number = 0;
        this.Records = new ArrayList<Record>();
        Record r0 = new Record(0.0);
        Records.add(r0);
    }


    @Override
    //EFFECTS: Add the 55% of the given amount into the given BasicSaving Account.
    public boolean addMoney(Account a, int number, double newAmount) {

        amount = a.getAmount() + newAmount*0.5;
        Record r = new Record(newAmount*0.5);
        Manager m = new Manager();
        r.addObserver(m);
        a.addRecord(r);
        return true;
    }

}
